#include "Action.h"

Action::~Action() {
}

KeyAction::~KeyAction() {}
